$ ('.slider').slick({
dots:true,
 autoplay: true   
 });
$ ('.conteinerPost').slick({
dots:true,
 autoplay: true   
 });









